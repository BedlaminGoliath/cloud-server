# cloud-server

a simple server for to test my AWS cloud

